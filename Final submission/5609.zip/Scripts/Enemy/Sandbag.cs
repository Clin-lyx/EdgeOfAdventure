using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sandbag : Enemy
{
    protected override void Awake()
    {
        base.Awake();
    }
    
}
