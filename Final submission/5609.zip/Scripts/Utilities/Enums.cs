public enum NPCState
{
    Patrol, Chase, Encounter, Skill
}

public enum SceneType
{
    Location, Menu, Character
}

public enum PersistentType
{
    ReadWrite, DoNotPersist
}