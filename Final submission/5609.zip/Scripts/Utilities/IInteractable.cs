using System.Collections;
public interface IInteractable
{
    void TriggerAction();
    
}
